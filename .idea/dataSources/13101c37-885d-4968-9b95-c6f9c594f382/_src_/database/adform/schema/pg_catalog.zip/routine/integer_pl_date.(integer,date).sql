create function pg_catalog.integer_pl_date(integer, date) returns date
IMMUTABLE
LANGUAGE SQL
AS $$
select $2 + $1
$$;
