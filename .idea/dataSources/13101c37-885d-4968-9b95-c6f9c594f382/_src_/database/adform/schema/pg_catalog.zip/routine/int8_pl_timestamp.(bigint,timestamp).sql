create function pg_catalog.int8_pl_timestamp(bigint, timestamp without time zone) returns timestamp without time zone
IMMUTABLE
LANGUAGE SQL
AS $$
select $2 + $1
$$;
