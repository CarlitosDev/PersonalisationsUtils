create function pg_catalog.regexp_instr(text, text) returns integer
IMMUTABLE
LANGUAGE SQL
AS $$
select regexp_instr($1, $2, 1)
$$;
