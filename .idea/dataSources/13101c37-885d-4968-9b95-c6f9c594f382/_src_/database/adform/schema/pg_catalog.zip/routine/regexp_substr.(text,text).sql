create function pg_catalog.regexp_substr(text, text) returns text
IMMUTABLE
LANGUAGE SQL
AS $$
select regexp_substr($1, $2, 1)
$$;
