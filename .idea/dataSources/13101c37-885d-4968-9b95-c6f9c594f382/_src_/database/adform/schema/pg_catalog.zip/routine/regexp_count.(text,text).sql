create function pg_catalog.regexp_count(text, text) returns integer
IMMUTABLE
LANGUAGE SQL
AS $$
select regexp_count($1, $2, 1)
$$;
