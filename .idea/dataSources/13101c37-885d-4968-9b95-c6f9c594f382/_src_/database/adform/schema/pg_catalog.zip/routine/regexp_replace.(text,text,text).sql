create function pg_catalog.regexp_replace(text, text, text) returns text
IMMUTABLE
LANGUAGE SQL
AS $$
select regexp_replace($1, $2, $3, 1)
$$;
