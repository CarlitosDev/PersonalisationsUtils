create function information_schema."_pg_truetypid"(pg_attribute, pg_type) returns oid
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT CASE WHEN $2.typtype = 'd' THEN $2.typbasetype ELSE $1.atttypid END
$$;
