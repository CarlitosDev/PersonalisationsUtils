create function information_schema."_pg_keypositions"() returns integer
IMMUTABLE
LANGUAGE SQL
AS $$
select g.s
        from generate_series(1,current_setting('max_index_keys')::int,1)
        as g(s)
$$;
