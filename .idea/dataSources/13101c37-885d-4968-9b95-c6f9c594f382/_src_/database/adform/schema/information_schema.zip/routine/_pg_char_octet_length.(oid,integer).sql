create function information_schema."_pg_char_octet_length"(typid oid, typmod integer) returns integer
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT
  CASE WHEN $1 IN (25, 1042, 1043) /* text, char, varchar */
       THEN CAST(2^30 AS integer)
       ELSE null
  END
$$;
